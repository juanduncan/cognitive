#!/usr/bin/env python
##################################################
# Gnuradio Python Flow Graph
# Title: ADS-B Hierarchical
# Author: Omar
# Description: ADS-B Hierarchical block
# Generated: Thu Nov  5 13:01:34 2015
##################################################

from gnuradio import analog
from gnuradio import blocks
from gnuradio import gr
from gnuradio.filter import firdes
import adsb

class hier_adsb(gr.hier_block2):

    def __init__(self):
        gr.hier_block2.__init__(
            self, "ADS-B Hierarchical",
            gr.io_signature(0, 0, 0),
            gr.io_signature(1, 1, gr.sizeof_gr_complex*1),
        )

        ##################################################
        # Variables
        ##################################################
        self.samp_rate_0 = samp_rate_0 = 4e6
        self.samp_rate = samp_rate = 4e6

        ##################################################
        # Blocks
        ##################################################
        self.blocks_interleave_0 = blocks.interleave(gr.sizeof_float*1)
        self.blocks_float_to_complex_0 = blocks.float_to_complex(1)
        self.blocks_char_to_float_0 = blocks.char_to_float(1, 1)
        self.analog_const_source_x_0 = analog.sig_source_i(0, analog.GR_CONST_WAVE, 0, 0, 1)
        self.adsb_out_0 = adsb.out()

        ##################################################
        # Connections
        ##################################################
        self.connect((self.blocks_float_to_complex_0, 0), (self, 0))
        self.connect((self.blocks_interleave_0, 0), (self.blocks_float_to_complex_0, 0))
        self.connect((self.blocks_char_to_float_0, 0), (self.blocks_interleave_0, 0))
        self.connect((self.adsb_out_0, 0), (self.blocks_char_to_float_0, 0))
        self.connect((self.analog_const_source_x_0, 0), (self.adsb_out_0, 0))
        self.connect((self.blocks_char_to_float_0, 0), (self.blocks_interleave_0, 1))


# QT sink close method reimplementation

    def get_samp_rate_0(self):
        return self.samp_rate_0

    def set_samp_rate_0(self, samp_rate_0):
        self.samp_rate_0 = samp_rate_0

    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate


