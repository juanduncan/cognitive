#!/usr/bin/env python
# -*- coding: utf-8 -*-
# 
# Copyright 2015 <+YOU OR YOUR COMPANY+>.
# 
# This is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
# 
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this software; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street,
# Boston, MA 02110-1301, USA.
# 

from PyQt4 import Qt
from PyQt4.QtCore import QObject, pyqtSlot
from gnuradio import analog
from gnuradio import blocks
from gnuradio import eng_notation
from gnuradio import filter
from gnuradio import gr
from gnuradio import qtgui
from gnuradio.eng_option import eng_option
from gnuradio.filter import firdes
import threading
from optparse import OptionParser
import PyQt4.Qwt5 as Qwt
import threading

import math
import nutaq
import sip
import sys
import time 
import DME
############## MOD 26/03/2015
import os
import subprocess

bandwidth = 15 # 1.5 MHz
# calib_fc = 1201e6 #1041e6 # Calibration frequency Mirabel's freq
calib_fc = 963e6 #1041e6 # Calibration frequency

# Receiver amplifier #2 gain limits
Max_RG2 = 30 
Min_RG2 = 0 
# Receiver amplifier #3 gain limits
Min_RG3 = -13
Max_RG3 = 18


cal_flag = False #Calibrate at start


def showprogress(progress):
    if progress == 0: sys.stdout.write("/\b")
    if progress == 1: sys.stdout.write("-\b")
    if progress == 2: sys.stdout.write("\\\b")
    if progress == 3: sys.stdout.write("|\b")
    progress += 1
    if progress == 4: progress = 0
    
    sys.stdout.flush()
    time.sleep(0.2)
    return progress

def showprogress_2(progress):
    sys.stdout.write( "++ Set Bias: %s\r" %(progress) ) 
    sys.stdout.flush()
    time.sleep(0.05)










class hier_dme(gr.hier_block2,Qt.QWidget):
    """
    docstring for block jerar
    """
    def __init__(self, vor):
        gr.hier_block2.__init__(
            self, "DME Hierarchical",
            gr.io_signature(1, 1, gr.sizeof_gr_complex),
            gr.io_signature(1, 1, gr.sizeof_gr_complex),
        )

            # Define blocks and connect them
        
            
        Qt.QWidget.__init__(self)

        self.setWindowTitle("DME")
        try:
             self.setWindowIcon(Qt.QIcon.fromTheme('gnuradio-grc'))
        except:
             pass
        
      
  
        #self.radioTx = radioTx = radioTx
        #self.radioRx = radioRx = radioRx
        #self.options = options = options
        #self.main = main = main
        #self.rtdexID = rtdexID = rtdexID
             
        self.top_scroll_layout = Qt.QVBoxLayout()
        self.setLayout(self.top_scroll_layout)
        self.top_scroll = Qt.QScrollArea()
        self.top_scroll.setFrameStyle(Qt.QFrame.NoFrame)
        self.top_scroll_layout.addWidget(self.top_scroll)
        self.top_scroll.setWidgetResizable(True)
        self.top_widget = Qt.QWidget()
        self.top_scroll.setWidget(self.top_widget)
        self.top_layout = Qt.QVBoxLayout(self.top_widget)
        self.top_grid_layout = Qt.QGridLayout()
        self.top_layout.addLayout(self.top_grid_layout)
        
        self.settings = Qt.QSettings("GNU Radio", "DME Hierarchical")
        self.restoreGeometry(self.settings.value("geometry").toByteArray())
        
        self.AUF_stop = threading.Event()
        
 

#####################################################################
#####################################################################
############################  DME  ##################################
#####################################################################
#####################################################################

        ##################################################
        # Events
        ##################################################
        self.CLI = threading.Thread( target=self.CommandLineInterface )
        
        ##################################################
        # Events
        ##################################################
        self.AGC_stop = threading.Event()
        self.CLI_stop = threading.Event()
        self.CAL_stop = threading.Event()
        self.PTH_stop = threading.Event()
        
        
        ##################################################
        # Variables
        ##################################################      
        self.variable_qtgui_label_0 = variable_qtgui_label_0 = 0
        self.variable_qtgui_entry_0 = variable_qtgui_entry_0 = 0



        self.samp_rate = samp_rate =1e6   #= main.samp_rate
        self.dme_samp_freq = dme_samp_freq = 1e6   #/decimation_factor
        self.bandwidth = bandwidth
        self.fc_Rx = fc_Rx = calib_fc
        self.fc_Tx = fc_Tx = calib_fc #1041e6
        self.G_Tx = G_Tx =  0      #JUAN options.tx_gain3_cal
        self.calib_fc = calib_fc
        self.calib_reseted = False
        self.Mode = Mode = 'X'
        self.Channel = Channel = None  #default for calibration
        self.VOR = VOR = vor  #JUAN options.VOR
        self.previous_VOR = vor  #JUAN options.VOR
        self.rx_gain2 = rx_gain2 =0  #JUAN options.rx_gain2
        self.rx_gain3 = rx_gain3 =5  #JUAN options.rx_gain3
        self.agcwindow = 100e-3 #seconds
        self.AGC_updaterate = self.agcwindow
        self.IOScale = IOScale = 1 #2**11-1          
        #JUAN self.filter_taps = filter.firdes.low_pass_2(3,samp_rate,dme_samp_freq/4,dme_samp_freq/4,60,5,6.76)

        
        ##################################################
        # Message Queues
        ##################################################
        DMEmessage_out = DMEmessage_in = gr.msg_queue(2)
        
        ##################################################
        # Knobs
        ##################################################

        ##################################################
        # Blocks
        ##################################################   
        #self.blocks_delay_0 = blocks.delay(gr.sizeof_gr_complex*1, 200)
        
        
		#VOR entry
        self._VOR_tool_bar = Qt.QToolBar(self)
        self._VOR_tool_bar.addWidget(Qt.QLabel("VOR = "))
        self._VOR_line_edit = Qt.QLineEdit(str(self.VOR))
        self._VOR_tool_bar.addWidget(self._VOR_line_edit)
        self._VOR_line_edit.returnPressed.connect(
            lambda: self.set_channel(float(self._VOR_line_edit.text().toAscii())))
        self.top_grid_layout.addWidget(self._VOR_tool_bar,8,1,2,2)                
        
        
        
        #DME blocks
        self.DME_interrogator = DME.dmeint_ff(dme_samp_freq)
        # (self.DME_interrogator).set_processor_affinity([5])
        # (self.DME_interrogator).set_processor_affinity([4, 5, 6, 7])
        (self.DME_interrogator).set_thread_priority(97)
        print '++'
        print '+'*67
        
        ## Output formatting
        self.scaler_Tx = blocks.multiply_const_vff((IOScale, ))
        # (self.scaler_Tx).set_processor_affinity([5])
       # (self.scaler_Tx).set_processor_affinity([4, 5, 6, 7])
        # (self.scaler_Tx).set_thread_priority(99)
        self.float_to_complex_Tx = blocks.float_to_complex(1)
        # (self.float_to_complex_Tx).set_processor_affinity([5])
        # (self.float_to_complex_Tx).set_processor_affinity([4, 5, 6, 7])
        # (self.float_to_complex_Tx).set_thread_priority(99)
        self.complex_to_interleaved_short_Tx = blocks.complex_to_interleaved_short()
        # (self.complex_to_interleaved_short_Tx).set_processor_affinity([5])
       # (self.complex_to_interleaved_short_Tx).set_processor_affinity([4, 5, 6, 7])
        # (self.complex_to_interleaved_short_Tx).set_thread_priority(99)
        
        ## Input formatting
        self.interleaved_short_to_complex_Rx = blocks.interleaved_short_to_complex(False)
        # (self.interleaved_short_to_complex_Rx).set_processor_affinity([5])
       # (self.interleaved_short_to_complex_Rx).set_processor_affinity([4, 5, 6, 7])
        # (self.interleaved_short_to_complex_Rx).set_thread_priority(99)
        # self.scaler_Rx = blocks.multiply_const_vcc((1.0/IOScale, ))
        self.scaler_Rx = blocks.multiply_const_vff((1.0/(IOScale**2), ))
        # (self.scaler_Rx).set_processor_affinity([5])
       # (self.scaler_Rx).set_processor_affinity([4, 5, 6, 7])
        # (self.scaler_Rx).set_thread_priority(99)
        self.complex_to_mag_squared_Rx = blocks.complex_to_mag_squared(1)
        # (self.complex_to_mag_squared_Rx).set_processor_affinity([5])
       # (self.complex_to_mag_squared_Rx).set_processor_affinity([4, 5, 6, 7])
        # (self.complex_to_mag_squared_Rx).set_thread_priority(99)

        

        # AGC
        # self.agc = nutaq.agc_maxhold_f(int(self.agcwindow*dme_samp_freq), 0.9, 0.3, 5) # Variability margin of 5 dB (Up=3*Low)
# #        (self.agc).set_processor_affinity([7])
#         (self.agc).set_processor_affinity([4, 5, 6, 7])
#         (self.agc).set_thread_priority(20)

        
        
        
        
        
        
        
        
        
        ##################################################
        # Connections
        ##################################################        
        #self.connect((self, 0), (self.blocks_delay_0, 0))
        #self.connect((self.blocks_delay_0, 0), (self, 0))    
        
        
        # Tx
        self.connect((self.DME_interrogator, 0), (self.scaler_Tx, 0))
        self.connect((self.scaler_Tx, 0), (self.float_to_complex_Tx, 0))
        self.connect((self.float_to_complex_Tx, 0), (self, 0))



        

        
        # Rx
   

        self.connect((self, 0), (self.complex_to_mag_squared_Rx, 0))

        self.connect((self.complex_to_mag_squared_Rx, 0), (self.scaler_Rx, 0))
        self.connect((self.scaler_Rx, 0), (self.DME_interrogator, 0))
            
            
#####################################################################
#####################################################################
###################   DME USED FUNCTIONS   ##########################
#####################################################################
#####################################################################            
    
    # Getting and setting values
    def get_samp_rate(self):
        return self.samp_rate

    def get_rx_gain2(self):
        return self.rx_gain2

    def set_rx_gain2(self, gain2):
        self.radioRx.set_rx_gain2(gain2)
        self.rx_gain2 = int(round(gain2/3)*3)

    def get_rx_gain3(self):
        return self.rx_gain3

    def set_rx_gain3(self, gain3):
        self.radioRx.set_rx_gain3(gain3)
        self.rx_gain3 = gain3

    def set_radio(self, radio_rx, radio_tx):
        self.radioRx = radio_rx
        self.radioTx = radio_tx


    # Print datas when the channel changes
    def print_mode(self):
        
        print '+'*67
        print '++'
        print '++ - R420 Sampling frequency = %0.2f MHz' % self.samp_rate
        print '++ - DME Sampling frequency = %0.2f MHz' % self.dme_samp_freq
        print '++ - Mode =', self.Mode, ' Channel =', self.Channel
        print '++ - VOR frequency = %0.2f MHz' % float(self.VOR)
        print '++ - Response RF = %(#)0.0f MHz' % {"#": self.fc_Rx/1e6}
        print '++ - Interrogation RF = %(#)0.0f MHz' % {"#": self.fc_Tx/1e6}
        print '++'
        print '+'*67
        
        self._VOR_line_edit.setText(eng_notation.num_to_str(self.VOR))

    # Changing the channel asfunction of the VOR
    def set_channel(self, VOR):      
        # VOR Frequency
        self.VOR = VOR
        VOR = float(VOR)
        channel = self.Channel

        self.main._variable2_label.setText(eng_notation.num_to_str(self.samp_rate))
        self.main._variable_label.setText(eng_notation.num_to_str(self.samp_rate))
     
        if self.calib_reseted:
            print "    ERROR: Change channel is fobidden during calibration"
        else:
            # Set the channel
            if VOR == 0: self.Channel = 0
            elif 108.0 <= VOR and VOR <= 112.25: self.Channel = int(math.floor(VOR*10)) - 1063
            elif 112.3 <= VOR and VOR <= 117.95: self.Channel = int(math.floor(VOR*10)) - 1053
            # Not paired: 
            elif 133.3 <= VOR and VOR <= 134.25: self.Channel = int(math.floor(VOR*10)) - 1273
            elif 134.4 <= VOR and VOR <= 135.85: self.Channel = int(math.floor(VOR*10)) - 1343
            else: self.Channel = channel

            if self.Channel != channel:
                # Set the mode and thus the frequencies # VOR = 0 for Calibration
                fc_Tx = (self.Channel + 1024) * 1e6
                if VOR == 0:
                    self.Mode = 'Cal'
                    fc_Rx = self.calib_fc
                    fc_Tx = self.calib_fc
                    self.DME_interrogator.set_Mode(True) # Only Mode X has equal Tx/Rx Pulse spacing
                elif VOR*10 == math.floor(VOR*10):
                    self.Mode = 'X'
                    if self.Channel <= 63: fc_Rx = fc_Tx - 63e6 
                    if self.Channel > 63: fc_Rx = fc_Tx + 63e6
                    if not(self.DME_interrogator.get_Mode()):
                        self.DME_interrogator.set_Mode(True)
                    self.previous_VOR = VOR
                else: 
                    self.Mode = 'Y'
                    if self.Channel <= 63: fc_Rx = fc_Tx + 63e6 
                    if self.Channel > 63: fc_Rx = fc_Tx - 63e6 
                    if self.DME_interrogator.get_Mode():
                        self.DME_interrogator.set_Mode(False)
                    self.previous_VOR = VOR
                              
                # Set the frequencies
                if (self.fc_Tx != fc_Tx):
                    self.fc_Tx = fc_Tx
                    if self.options.platform in {"pico", "zepto"} :
                        self.radioTx.set_tx_freq(self.fc_Tx)
                if (self.fc_Rx != fc_Rx):
                    self.fc_Rx = fc_Rx
                    if self.options.platform in {"pico", "zepto"} :
                        self.radioRx.set_rx_freq(self.fc_Rx)
                
                # Show summary
                self.print_mode()

            else: 
                print "    ERROR: Wrong VOR, please enter a correct VOR frequency"            
          
    def agc_impl(self, measured_power_cr, update_rate, mode):        
        print "++"
        print "++ Starting AGC ..."
        increase = 0
        error = 0
        integral = 0 
        rx_gain2 = 0
        rx_gain3 = 0 

        if self.options.platform in {"pico", "zepto"} :
            while not(self.main.nutaq_carrier_perseus_0.is_peripheral_reseted(1)):
                time.sleep(0.5)
            while (not self.AGC_stop.is_set()):                
                ###### DEBUG
                # time.sleep(.5)
                # print "Power: %d" %(measured_power_cr.get_value())
                # print "AGC_MODE: %d" %(mode)
                ######
                ###### 
                
                if mode == 1 :         #Direct assing Table 

                    past_ctrl_val = ( max(0,min(63, measured_power_cr.get_value() ) ) )                    
                    if past_ctrl_val < 32 :
                        rx_gain3 = past_ctrl_val -13
                        rx_gain2 = 0
                    else :
                        rx_gain3 = Max_RG3
                        rx_gain2 = past_ctrl_val -31

                    #~ self.radioRx.set_rx_gain3(rx_gain3)
                    self.set_rx_gain3(rx_gain3)
                    self.set_rx_gain2(rx_gain2)
                    #~ self.radioRx.set_rx_gain2(rx_gain2)

                    time.sleep(update_rate)

                elif mode == 2 :        #Increase based Gain calculation
          
                    self.agc.reset_increase()
                    time.sleep(self.AGC_updaterate)
                    increase = int(0.5*increase + 0.6*self.agc.get_increase())
                    
                    if increase > 0:
                        if rx_gain3 < Max_RG3: 
                            rx_gain3 = min(Max_RG3, rx_gain3 + max(1,increase))
                        elif rx_gain2 < Max_RG2:
                            rx_gain2 = min(Max_RG2, rx_gain2 + max(1,increase))                   
                        self.radioRx.set_rx_gain3(rx_gain3)
                        self.radioRx.set_rx_gain2(rx_gain2)
                        time.sleep(self.AGC_updaterate)            
                    elif increase < 0:
                        if rx_gain2 > Min_RG2: 
                            rx_gain2 = max(Min_RG2, rx_gain2 + min(-1,increase))
                            # radioID.set_rx_gain2(rx_gain2)
                        elif rx_gain3 > Min_RG3: 
                            rx_gain3 = max(Min_RG3, rx_gain3 + min(-1,increase))
                            # radioID.set_rx_gain3(rx_gain3)
                        #~ self.radioRx.set_rx_gain3(rx_gain3)
                        self.set_rx_gain3(rx_gain3)
                        self.set_rx_gain2(rx_gain2)
                        #~ self.radioRx.set_rx_gain2(rx_gain2)
                        time.sleep(self.AGC_updaterate)

                # print '[{0:5d}] Gain3: {1:5d}, Gain2: {2:5d}, '.format(increase, rx_gain3, rx_gain2)               
            
            print "++"
            print "++ AGC thread ended"
        
    # QT sink close method reimplementation
    def closeEvent(self, event):
        self.settings = Qt.QSettings("GNU Radio", "ACDME")
        self.settings.setValue("geometry", self.saveGeometry())
        event.accept()
      
    def CommandLineInterface(self):
        print "++"
        print "++ Starting Command Line Interface ..."
        while (not self.CLI_stop.is_set()):            
            command = raw_input('++ Introduce a command: \n++\n')
            if command == "" : 
                pass
                # print '++ CR18: %d ' % (self.main.nutaq_custom_register_18.get_value())
                print '++ CR30: %d ' % (self.main.nutaq_custom_register_30.get_value())
                print '++ CR31: %d ' % (self.main.nutaq_custom_register_31.get_value())
            elif command == "exit" : break
            else :
                try :
                    self.VOR = float(command)          
                    if self.VOR < 136 and self.VOR >= 108 : self.set_channel(self.VOR)
                except ValueError :
                    print("++ Unknown Command")
        print "++"
        print "++ Exiting Command Line Interface ..."

    def BiasCal(self):
        # Measuring elapsed time

        print "++ Starting CAL ..."
        print (self.filter_taps)

        self.start_time = time.time()

        if self.options.platform in {"pico", "zepto"} :
            print '+'*67
            print "++"
            print "++ Waiting for Nutaq's calibration ..."
            print "++"
            print '+'*67 + '\n'
            waittime = 0
            progress = 0
            # reseted = False
            #Just set the calibration channel once in the routine
            self.set_channel(0) 
            # self.set_channel(self.options.VOR)
            while (not self.CAL_stop.is_set() ):
                if not(self.main.nutaq_carrier_perseus_0.is_peripheral_reseted(1)):
                    waittime += 1
                    time.sleep(0.001)
                elif self.calib_reseted == False:
                    print "Initialization done in %(#)0.1f sec." % {"#": waittime/10}
                    print '+'*67
                    # Check if calibrated
                    print "++"
                    # sys.stdout.write("++ Calibrating DME...  ")
                    print "++ Calibrating DME...  "
                    self.calib_reseted = True
                elif self.calib_reseted:
                    # print "PERDIDO!!!" 
                    if self.DME_interrogator.get_Calibration_Mode():    
                        # progress = showprogress(progress)
                        progress = showprogress_2((self.DME_interrogator.get_Bias()/self.dme_samp_freq*1000))
                        # print "SI ENTRO PERO ME HAGO GUEY!!!" 
                    else:
                        sys.stdout.flush()
                        sys.stdout.write("\r++ Done.")
                        # sys.stdout.write("/\n")
                        # Calibrated: Print and go to Normal Mode
                        print '++ - Bias: %0.3f ms' % (self.DME_interrogator.get_Bias()/self.dme_samp_freq*1000)
                        print "++"
                        ## Go to normal Mode
                        self.rx_gain2 = Min_RG2
                        self.set_rx_gain2(Min_RG2)
                        self.rx_gain3 = Min_RG3
                        self.set_rx_gain3(Min_RG3)

                        self.calib_reseted = False
                        self.set_channel(self.previous_VOR)
                        # self.set_G_Tx(self.options.tx_gain3)

                        self.CAL_stop.set()
                            # Prompt for commands                        
                        # self.nutaq_radio420_rx_0.set_default_rx_vga1_gain(2)
                        # self.nutaq_radio420_rx_0.set_default_rx_gain_ctrl(0)

                        # self.CLI.start()
                        # break
            print "++"
            print "++ Calibration thread ended"            
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
