/* -*- c++ -*- */
/* 
 * Copyright 2015 <+YOU OR YOUR COMPANY+>.
 * 
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 * 
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */


#ifndef INCLUDED_AVIO505_CONTROLLER_H
#define INCLUDED_AVIO505_CONTROLLER_H

#include <avio505/api.h>
#include <gnuradio/block.h>
#include <avio505/three_ch_multip_rtdex.h>
#include <nutaq/radio420_tx.h>
#include <nutaq/radio420_rx.h>
#include <nutaq/custom_register.h>

namespace gr {
  namespace avio505 {

    /*!
     * \brief Used to interface GUI and Nutaq blocks
     * \ingroup avio505
     *
     */
    class AVIO505_API Controller : virtual public gr::block
    {
     protected:
	  /* Other blocks */
      static boost::shared_ptr<gr::nutaq::radio420_tx> d_radio1_tx;
      static boost::shared_ptr<gr::nutaq::radio420_rx> d_radio1_rx;
      static boost::shared_ptr<gr::nutaq::radio420_tx> d_radio2_tx;
      static boost::shared_ptr<gr::nutaq::radio420_rx> d_radio2_rx;
      static boost::shared_ptr<gr::nutaq::custom_register> d_radio_switcher;

	  /* Radio control */
	  static int d_system_radio1, d_system_radio2, d_radio_switcher_value;
      static float d_radio1_tx_freq, d_radio1_rx_freq;
      static float d_radio2_tx_freq, d_radio2_rx_freq;

	  /* DME control */
      static float d_vor_freq_dme1, d_vor_freq_dme2;

     public:     
      typedef boost::shared_ptr<Controller> sptr;

      /*!
       * \brief Return a shared_ptr to a new instance of avio505::Controller.
       *
       * To avoid accidental use of raw pointers, avio505::Controller's
       * constructor is in a private implementation
       * class. avio505::Controller::make is the public interface for
       * creating new instances.
       */
      static sptr make(int system_radio1, 
		boost::shared_ptr<gr::nutaq::radio420_tx> radio1_tx,
		boost::shared_ptr<gr::nutaq::radio420_rx> radio1_rx,
		int system_radio2,
		boost::shared_ptr<gr::nutaq::radio420_tx> radio2_tx,
		boost::shared_ptr<gr::nutaq::radio420_rx> radio2_rx,
		boost::shared_ptr<gr::nutaq::custom_register> radio_switcher,
		float vor_freq_dme1, float vor_freq_dme2);
      
      /*!
       * \brief Necessary changes when SDA operating at Radio#1 changes.
       */
      static void system_change_radio1(int system_radio1);
      
      /*!
       * \brief Necessary changes when SDA operating at Radio#1 changes.
       */
      static void system_change_radio2(int system_radio2);
      
      /*!
       * \brief Get the value to written in custom register 28
       */
       static int get_switcher_value(int system_radio1, int system_radio2);
       
      /*!
       * \brief Necessary changes when DME1 frequency changes.
       */
      static void freq_change_dme1(float vor_freq_dme1);

      /*!
       * \brief Necessary changes when DME1 frequency changes.
       */
      static void freq_change_dme2(float vor_freq_dme2);

	  /*!
	   * \brief Compute DME TX/RX frequency
	   */
	  static float get_dme_tx_freq(float vor_freq, int dme_system);
	  static float get_dme_rx_freq(float vor_freq, float tx_freq, int dme_system);
    };

  } // namespace avio505
} // namespace gr

#endif /* INCLUDED_AVIO505_CONTROLLER_H */

