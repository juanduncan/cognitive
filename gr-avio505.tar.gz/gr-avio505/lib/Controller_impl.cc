/* -*- c++ -*- */
/* 
 * Copyright 2015 LASSENA.
 * 
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 * 
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#define MHZ 1000000
#define ADS_B_OUT_FREQ 1090.0

#include <gnuradio/io_signature.h>
#include "Controller_impl.h"
#include <math.h> /* fmod, floor */

using namespace std;

namespace gr {
  namespace avio505 {
	  

	/* Other blocks */
    boost::shared_ptr<gr::nutaq::radio420_tx> Controller::d_radio1_tx;
    boost::shared_ptr<gr::nutaq::radio420_rx> Controller::d_radio1_rx;
    boost::shared_ptr<gr::nutaq::radio420_tx> Controller::d_radio2_tx;
    boost::shared_ptr<gr::nutaq::radio420_rx> Controller::d_radio2_rx;
    boost::shared_ptr<gr::nutaq::custom_register> Controller::d_radio_switcher;

	/* Radio control */
	int Controller::d_system_radio1, Controller::d_system_radio2, Controller::d_radio_switcher_value;
    float Controller::d_radio1_tx_freq, Controller::d_radio1_rx_freq;
    float Controller::d_radio2_tx_freq, Controller::d_radio2_rx_freq;

    /* DME control */
    float Controller::d_vor_freq_dme1, Controller::d_vor_freq_dme2;

	/* Public methods */
    Controller::sptr
    Controller::make(int system_radio1, 
		boost::shared_ptr<gr::nutaq::radio420_tx> radio1_tx,
		boost::shared_ptr<gr::nutaq::radio420_rx> radio1_rx,
		int system_radio2,
		boost::shared_ptr<gr::nutaq::radio420_tx> radio2_tx,
		boost::shared_ptr<gr::nutaq::radio420_rx> radio2_rx,
		boost::shared_ptr<gr::nutaq::custom_register> radio_switcher,
		float vor_freq_dme1, float vor_freq_dme2)
    {
      return gnuradio::get_initial_sptr
        (new Controller_impl(system_radio1, 
		radio1_tx,
		radio1_rx,		
		system_radio2,
		radio2_tx,
		radio2_rx,		
		radio_switcher,
		vor_freq_dme1, vor_freq_dme2));
    }

	void
	Controller::system_change_radio1(int system_radio1)
	{
		/* Disable radio for reconfiguration */
		d_radio1_tx->disable_path();
		d_radio1_rx->disable_path();

		/* Stop current system in gnuradio */
		// TODO: switch OFF (d_system_radio1)
		
		cout << "[Control:] Changing Radio1 from system " << d_system_radio1 << " to system " << system_radio1 << endl;
		d_system_radio1 = system_radio1;

		/* Configure the FPGA's switch matrix */
		d_radio_switcher_value = get_switcher_value(d_system_radio1, d_system_radio2);
		d_radio_switcher->set_value(d_radio_switcher_value);
		
		/* Compute radio parameters */
		switch (d_system_radio1)
		{
			case 0: // None
				/* Disable radios */
				d_radio1_tx->disable_path();
				d_radio1_rx->disable_path();
				break;
		
			case 1: // ADS-B
				d_radio1_tx_freq = ADS_B_OUT_FREQ;
				d_radio1_rx_freq = ADS_B_OUT_FREQ;
				break;
				
			case 2: // DME1
				/*d_radio1_tx->set_tx_freq(963*MHZ);
				d_radio1_rx->set_rx_freq(963*MHZ);
				sleep(5);*/
				d_radio1_tx_freq = get_dme_tx_freq(d_vor_freq_dme1, 1);
				d_radio1_rx_freq = get_dme_rx_freq(d_vor_freq_dme1, d_radio1_tx_freq, 1);
				break;
				
			case 3: // DME2
				/*d_radio1_tx->set_tx_freq(963*MHZ);
				d_radio1_rx->set_rx_freq(963*MHZ);
				sleep(5);*/
				d_radio1_tx_freq = get_dme_tx_freq(d_vor_freq_dme2, 2);
				d_radio1_rx_freq = get_dme_rx_freq(d_vor_freq_dme2, d_radio1_tx_freq, 2);
				break;
		};

		/* Update radio parameters */
		if (d_system_radio1 != 0)
		{
			cout << "[Control:] Radio1 TX frequency " << d_radio1_tx_freq << "MHz" << endl;
			cout << "[Control:] Radio1 RX frequency " << d_radio1_rx_freq << "MHz" << endl;
			/* Note: It'd be better to reconfigure and then enable, but that doesn't work. Anyways, old system is OFF at the CPU level, so output should be zeroes. */
			d_radio1_tx->enable_path();
			d_radio1_rx->enable_path();
			d_radio1_tx->set_tx_freq(d_radio1_tx_freq*MHZ);
			d_radio1_rx->set_rx_freq(d_radio1_rx_freq*MHZ);
		}
		
		/* Restart new gnuradio system */
		// TODO: switch ON (d_system_radio1)
	}

	void
	Controller::system_change_radio2(int system_radio2)
	{
		/* Disable radio for reconfiguration */
		d_radio2_tx->disable_path();
		d_radio2_rx->disable_path();

		/* Stop current system in gnuradio */
		// TODO: switch OFF (d_system_radio1)
		
		cout << "[Control:] Changing Radio2 from system " << d_system_radio2 << " to system " << system_radio2 << endl;
		d_system_radio2 = system_radio2;

		/* Configure the FPGA's switch matrix */
		d_radio_switcher_value = get_switcher_value(d_system_radio1, d_system_radio2);		
		d_radio_switcher->set_value(d_radio_switcher_value);
		
		/* Compute radio parameters */
		switch (d_system_radio2)
		{
			case 0: // None
				/* Disable radios */
				d_radio2_tx->disable_path();
				d_radio2_rx->disable_path();
				break;
		
			case 1: // ADS-B
				d_radio2_tx_freq = ADS_B_OUT_FREQ;
				d_radio2_rx_freq = ADS_B_OUT_FREQ;
				break;
				
			case 2: // DME1
				/*d_radio2_tx->set_tx_freq(963*MHZ);
				d_radio2_rx->set_rx_freq(963*MHZ);
				sleep(5);*/
				d_radio2_tx_freq = get_dme_tx_freq(d_vor_freq_dme1, 2);
				d_radio2_rx_freq = get_dme_rx_freq(d_vor_freq_dme1, d_radio2_tx_freq, 2);
				break;
				
			case 3: // DME2
				/*d_radio2_tx->set_tx_freq(963*MHZ);
				d_radio2_rx->set_rx_freq(963*MHZ);
				sleep(5);*/
				d_radio2_tx_freq = get_dme_tx_freq(d_vor_freq_dme2, 2);
				d_radio2_rx_freq = get_dme_rx_freq(d_vor_freq_dme2, d_radio2_tx_freq, 2);
				break;
		};

		/* Update radio parameters */
		if (d_system_radio2 != 0)
		{
			cout << "[Control:] Radio2 TX frequency " << d_radio2_tx_freq << "MHz" << endl;
			cout << "[Control:] Radio2 RX frequency " << d_radio2_rx_freq << "MHz" << endl;
			/* Note: It'd be better to reconfigure and then enable, but that doesn't work. Anyways, old system is OFF at the CPU level, so output should be zeroes. */
			d_radio2_tx->enable_path();
			d_radio2_rx->enable_path();
			d_radio2_tx->set_tx_freq(d_radio2_tx_freq*MHZ);
			d_radio2_rx->set_rx_freq(d_radio2_rx_freq*MHZ);
		}
		
		/* Restart new gnuradio system */
		// TODO: switch ON (d_system_radio2)
	}

	int
	Controller::get_switcher_value(int system_radio1, int system_radio2)
	{
		int radio1_tx = system_radio1*64; // bits 6-7
		int radio2_tx = system_radio2*16; // bits 4-5
		/* All systems' receivers are connected to Radio1
		 * except the one operating at Radio2 */
		int radio2_rx = int(pow(2, float(3-system_radio2))); // bits 0-2
		cout << "[Control:] CR28 value: " << radio1_tx << 
									  " " << radio2_tx << 
									  " " << radio2_rx << endl;
		return (radio1_tx + radio2_tx + radio2_rx);
	}
	
    void
    Controller::freq_change_dme1(float vor_freq_dme1)
    {
		/* A priori, no need to stop radios */	
		d_vor_freq_dme1 = vor_freq_dme1;
		/* Check Radio1 */
		if (d_system_radio1 == 2)
		{
			/* Compute radio parameters */
			d_radio1_tx_freq = get_dme_tx_freq(d_vor_freq_dme1, 1);
			d_radio1_rx_freq = get_dme_rx_freq(d_vor_freq_dme1, d_radio1_tx_freq, 1);
			/* Update radio parameters */
			cout << "[Control:] Radio1 TX frequency " << d_radio1_tx_freq << "MHz" << endl;
			cout << "[Control:] Radio1 RX frequency " << d_radio1_rx_freq << "MHz" << endl;
			d_radio1_tx->set_tx_freq(d_radio1_tx_freq*MHZ);
			d_radio1_rx->set_rx_freq(d_radio1_rx_freq*MHZ);
		}
		/* Check Radio2 */
		if (d_system_radio2 == 2)
		{
			/* Compute radio parameters */
			d_radio2_tx_freq = get_dme_tx_freq(d_vor_freq_dme1, 1);
			d_radio2_rx_freq = get_dme_rx_freq(d_vor_freq_dme1, d_radio2_tx_freq, 1);
			/* Update radio parameters */
			cout << "[Control:] Radio2 TX frequency " << d_radio2_tx_freq << "MHz" << endl;
			cout << "[Control:] Radio2 RX frequency " << d_radio2_rx_freq << "MHz" << endl;
			d_radio2_tx->set_tx_freq(d_radio2_tx_freq*MHZ);
			d_radio2_rx->set_rx_freq(d_radio2_rx_freq*MHZ);
		}
	}
	
    void
    Controller::freq_change_dme2(float vor_freq_dme2)
    {
		/* A priori, no need to stop radios */	
		d_vor_freq_dme2 = vor_freq_dme2;
		/* Check Radio1 */
		if (d_system_radio1 == 3)
		{
			/* Compute radio parameters */
			d_radio1_tx_freq = get_dme_tx_freq(d_vor_freq_dme2, 2);
			d_radio1_rx_freq = get_dme_rx_freq(d_vor_freq_dme2, d_radio1_tx_freq, 2);
			/* Update radio parameters */
			cout << "[Control:] Radio1 TX frequency " << d_radio1_tx_freq << "MHz" << endl;
			cout << "[Control:] Radio1 RX frequency " << d_radio1_rx_freq << "MHz" << endl;
			d_radio1_tx->set_tx_freq(d_radio1_tx_freq*MHZ);
			d_radio1_rx->set_rx_freq(d_radio1_rx_freq*MHZ);
		}
		/* Check Radio2 */
		if (d_system_radio2 == 3)
		{
			/* Compute radio parameters */
			d_radio2_tx_freq = get_dme_tx_freq(d_vor_freq_dme2, 2);
			d_radio2_rx_freq = get_dme_rx_freq(d_vor_freq_dme2, d_radio2_tx_freq, 2);
			/* Update radio parameters */
			cout << "[Control:] Radio2 TX frequency " << d_radio2_tx_freq << "MHz" << endl;
			cout << "[Control:] Radio2 RX frequency " << d_radio2_rx_freq << "MHz" << endl;
			d_radio2_tx->set_tx_freq(d_radio2_tx_freq*MHZ);
			d_radio2_rx->set_rx_freq(d_radio2_rx_freq*MHZ);
		}
	}
	
	float
	Controller::get_dme_tx_freq(float vor_freq, int dme_system)
	{
		if ( (vor_freq >= 108.0) && (vor_freq < 112.3) )
			return floor(vor_freq*10)-39;
		else if ( (vor_freq >= 112.3) && (vor_freq < 118.0) )
			return floor(vor_freq*10)-29;
		else
			cout << "[Control:] Unrecognized DME" << dme_system << " VOR frequency" << endl;
			return -1;
	}

	float
	Controller::get_dme_rx_freq(float vor_freq, float tx_freq, int dme_system)
	{
		if ( (vor_freq - floor(vor_freq*10)/10) == 0.00 ) // X Mode				
			return tx_freq-63;
			/* TODO: set DME1 to X-Mode */
		else if ( abs(vor_freq - floor(vor_freq*10)/10 - 0.05) < 1e-5) // Y Mode
		/* Note: Due to float precision, 117.95 - floor(117.95*10)/10 != 0.05. Difference's about 4e-6 */ 	
			return tx_freq+63;
			/* TODO: set DME1 to Y-Mode */
		else
			cout << "[Control:] Unrecognized DME" << dme_system << " VOR frequency" << endl;
			return -1;
	}


    /*
     * The private constructor
     */
    Controller_impl::Controller_impl(int system_radio1, 
		boost::shared_ptr<gr::nutaq::radio420_tx> radio1_tx,
		boost::shared_ptr<gr::nutaq::radio420_rx> radio1_rx,
		int system_radio2,
		boost::shared_ptr<gr::nutaq::radio420_tx> radio2_tx,
		boost::shared_ptr<gr::nutaq::radio420_rx> radio2_rx,
		boost::shared_ptr<gr::nutaq::custom_register> radio_switcher,
		float vor_freq_dme1, float vor_freq_dme2)
      : gr::block("Controller",
              gr::io_signature::make(0, 0, sizeof(char)),
              gr::io_signature::make(0, 0, sizeof(char)))
    {	
		/* Radio 1 */
		d_radio1_tx = radio1_tx;
		d_radio1_rx = radio1_rx;
		d_system_radio1 = system_radio1;
		//system_change_radio1(system_radio1);

		/* Radio 2 */
		d_radio2_tx = radio2_tx;
		d_radio2_rx = radio2_rx;
		d_system_radio2 = system_radio2;
		
		/* Custom Register to switch radios */
		d_radio_switcher = radio_switcher;
		d_radio_switcher_value = (d_system_radio1*4 + d_system_radio2)*17;		
		
		/* DME 1 */
		d_vor_freq_dme1 = vor_freq_dme1;
		
		/* DME 2 */ 
		d_vor_freq_dme2 = vor_freq_dme2;
	}

    /*
     * Our virtual destructor.
     */
    Controller_impl::~Controller_impl()
    {
		d_radio1_tx->disable_path();
		d_radio2_tx->disable_path();
		d_radio1_rx->disable_path();
		d_radio2_rx->disable_path();
	}

  } /* namespace avio505 */
} /* namespace gr */

